package update;

public  interface  Observer {
	public void update( int i) ;
}
